toetsInlogPHP
=============

Check de index pagina voor de link naar de toetsinformatie
Je mag alles erbij houden wat je wilt, er wordt getoetst op je vaardigheden vandaag, niet op je kennis.

veel succes.
